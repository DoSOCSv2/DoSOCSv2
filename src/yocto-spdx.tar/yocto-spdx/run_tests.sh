#!/bin/bash

# SPDX-License-Identifier: MIT

if [[ `id -u` -eq 0 ]]
then
    echo "$0: must not be root!"
    exit 1
fi

if [[ ! -f ./`basename $0` ]]
then
    echo "$0: must run from own directory"
    exit 1
fi

cd ./src/tests

./setup.sh
ERRCODE=$?
if [[ "$ERRCODE" != "0" ]]
then
    echo "$0: test setup script returned exit status $ERRCODE"
    exit 1
fi

for TEST in ./test*.py
do
    ./$TEST $*
done
./teardown.sh
