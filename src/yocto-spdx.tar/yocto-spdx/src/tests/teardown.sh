#!/bin/bash

# SPDX-License-Identifier: MIT

if [[ ! -f ./`basename $0` ]]
then
    echo $0: need to run from own directory
    exit 1
fi

rm -f do_spdx.py*
