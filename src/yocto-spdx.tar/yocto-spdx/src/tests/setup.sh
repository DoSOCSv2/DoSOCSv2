#!/bin/bash
# extract python code from the spdx.bbclass file

# SPDX-License-Identifier: MIT

if [[ ! -f ./`basename $0` ]]
then
    echo $0: need to run from own directory
    exit 1
fi

T1=$(mktemp)
rm -f do_spdx.py*
grep -A 10000 "python do_spdx ()" ../spdx.bbclass | head -n -2 | tail -n +2 > $T1

cat << EOF > do_spdx.py
from mock import bb
def do_spdx(d):
EOF

cat $T1 >> do_spdx.py
rm -f $T1
