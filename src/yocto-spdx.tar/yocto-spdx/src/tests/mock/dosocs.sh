#!/bin/sh

# Fake DoSOCS
# Dumps its arguments to a file
# Always succeeds

# SPDX-License-Identifier: MIT

rm -f ./dosocs_flags.tmp
echo $* > ./dosocs_flags.tmp
