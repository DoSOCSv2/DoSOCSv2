"""Fake bb module, implementing only those methods used by Yocto+SPDX"""

# SPDX-License-Identifier: MIT

import os
import errno

def error(*args, **kwargs):
    pass

def warn(*args, **kwargs):
    pass

class utils:
    @staticmethod
    def mkdirhier(directory):
        try:
            os.makedirs(directory)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise e
