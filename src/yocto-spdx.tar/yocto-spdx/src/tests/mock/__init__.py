"""Mock objects for Yocto+SPDX unit tests."""

# SPDX-License-Identifier: MIT

class BitbakeEnvDict(dict):
    """Represents the bitbake environment."""
    def getVar(self, name, unused=False):
        return self.get(name)
