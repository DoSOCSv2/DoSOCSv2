#!/usr/bin/python2
"""Unit tests for Yocto+SPDX"""

# SPDX-License-Identifier: MIT

import os
import shutil
import subprocess
import tempfile
import unittest
from do_spdx import do_spdx
from mock import BitbakeEnvDict

class TestDoSPDX(unittest.TestCase):

    _dosocs_flags_path = './dosocs_flags.tmp'

    def _clean_manifest_dir(self):
        manifest_dir = self.d['SPDX_MANIFEST_DIR']
        try:
            os.remove(os.path.join(manifest_dir, self.d['PN'] + '.spdx'))
        except EnvironmentError:
            pass

    def _do_spdx(self):
        """Run do_spdx and return success status as a boolean."""
        return_value = do_spdx(self.d)
        return return_value is None

    def _spdx_output_created(self):
        manifest_dir = self.d['SPDX_MANIFEST_DIR']
        spdx_output = os.path.join(manifest_dir, self.d['PN'] + '.spdx')
        try:
            return os.path.isfile(spdx_output)
        except EnvironmentError:
            return False

    def _dosocs_flags(self):
        try:
            with open(self._dosocs_flags_path) as f:
                flags = f.read()
            return flags
        except EnvironmentError:
            return None

    def setUp(self):
        self.d = BitbakeEnvDict()
        self.d['WORKDIR'] = '.'
        self.d['S'] = './mock/hello-1.0'
        self.d['PN'] = 'hello'
        self.d['SPDX_MANIFEST_DIR'] = '.'
        self.d['SPDX_DOSOCS_PATH'] = './mock/dosocs.sh'
        self._clean_manifest_dir()

    def tearDown(self):
        self._clean_manifest_dir()
        try:
            os.remove(self._dosocs_flags_path)
        except EnvironmentError:
            pass

    def test_success_typical_case(self):
        self.assertTrue(self._do_spdx())
        self.assertTrue(self._spdx_output_created())

    def test_fail_nonexistent_dosocs_path(self):
        self.d['SPDX_DOSOCS_PATH'] = '/nonexistent'
        self.assertFalse(self._do_spdx())
        self.assertFalse(self._spdx_output_created())

    def test_fail_dosocs_no_execute_permission(self):
        self.d['SPDX_DOSOCS_PATH'] = '/dev/null'
        self.assertFalse(self._do_spdx())
        self.assertFalse(self._spdx_output_created())

    def test_success_manifest_dir_create_if_nonexistent(self):
        manifest_dir = tempfile.mkdtemp()
        os.rmdir(manifest_dir)
        self.d['SPDX_MANIFEST_DIR'] = manifest_dir
        self.assertTrue(self._do_spdx())
        self.assertTrue(os.path.isdir(manifest_dir))
        self.assertTrue(self._spdx_output_created())
        shutil.rmtree(manifest_dir)

    def test_fail_manifest_dir_not_a_dir(self):
        self.d['SPDX_MANIFEST_DIR'] = '/dev/null'
        self.assertFalse(self._do_spdx())
        self.assertFalse(self._spdx_output_created())

    def test_fail_manifest_dir_no_permission(self):
        self.d['SPDX_MANIFEST_DIR'] = '/root'
        self.assertFalse(self._do_spdx())
        self.assertFalse(self._spdx_output_created())

    def test_success_print_type_json(self):
        for j in ('JSON', 'json', 'jSoN'):
            self.d['SPDX_PRINT_FORMAT'] = j
            self.assertTrue(self._do_spdx())
            self.assertTrue(self._spdx_output_created())
            self.assertIn('json', self._dosocs_flags())

    def test_success_print_type_rdf(self):
        for j in ('RDF', 'rdf', 'rDf'):
            self.d['SPDX_PRINT_FORMAT'] = j
            self.assertTrue(self._do_spdx())
            self.assertTrue(self._spdx_output_created())
            self.assertIn('rdf', self._dosocs_flags())

    def test_success_print_type_tag(self):
        for j in ('TAG', 'tag', 'tAg'):
            self.d['SPDX_PRINT_FORMAT'] = j
            self.assertTrue(self._do_spdx())
            self.assertTrue(self._spdx_output_created())
            self.assertIn('tag', self._dosocs_flags())

    def test_success_print_type_not_specified_defaults_to_json(self):
        self.assertTrue(self._do_spdx())
        self.assertTrue(self._spdx_output_created())
        self.assertIn('json', self._dosocs_flags())

    def test_success_with_document_comment(self):
        self.d['SPDX_DOCUMENT_COMMENT'] = 'asdf'
        self.assertTrue(self._do_spdx())
        self.assertTrue(self._spdx_output_created())
        self.assertIn('--documentComment', self._dosocs_flags())
        self.assertIn('asdf', self._dosocs_flags())

    def test_success_with_creator_comment(self):
        self.d['SPDX_CREATOR_COMMENT'] = 'asdf'
        self.assertTrue(self._do_spdx())
        self.assertTrue(self._spdx_output_created())
        self.assertIn('--creatorComment', self._dosocs_flags())
        self.assertIn('asdf', self._dosocs_flags())

    def test_success_with_creator(self):
        self.d['SPDX_CREATOR'] = 'asdf'
        self.assertTrue(self._do_spdx())
        self.assertTrue(self._spdx_output_created())
        self.assertIn('--creator', self._dosocs_flags())
        self.assertIn('asdf', self._dosocs_flags())

    def test_fail_dosocs_returned_nonzero(self):
        self.d['SPDX_DOSOCS_PATH'] = '/bin/false'
        self.assertFalse(self._do_spdx())
        self.assertFalse(self._spdx_output_created())


if __name__ == '__main__':
    unittest.main()
