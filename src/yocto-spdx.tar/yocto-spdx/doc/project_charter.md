#PROJECT CHARTER

Project Title: UNO Yocto+SPDX

Project Sponsor: University of Nebraska at Omaha

Date Prepared: January 28, 2015

Project Manager: NA

Project Customer: Yocto Project and SPDX communities

###Project Purpose and Justification:

Embedded OS images created using the Yocto Project build process can
potentially contain an enormous number of open source packages, each
accompanied by a license that communicates the terms by which the software can
be used. Groups who create and distribute these OS images, as well as the users
of these images, face challenges in determining what their obligations are when
they distribute and/or use the software contained within.

###Project Description:

Yocto+SPDX aims to simplify the gathering of license information for the many
packages in a typical OS built using Yocto Project by seamlessly integrating
SPDX document generation into the build process. More information can be found
in README.md in the repository root.

###High-level Project and Product Requirements:
1. Linux
2. Python 2.7
3. DoSOCS
4. Yocto 

###Summary Budget:
There is no foreseeable cost for this project.

###Initial Risks:
N/A



