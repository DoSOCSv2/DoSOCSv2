###Use Case Number: 3

**Use Case Name:** Use a different SPDX document output format.

**Description:** By default the SPDX output is in JSON format, one might want
to use RDF or "tag" format instead.

**Preconditions:**
- DoSOCS installed and configured
- Poky build system downloaded and configured
- Yocto+SPDX installed, with bitbake variable `DOSOCS_PATH` set to the
  location of the DoSOCS executable and `USER_CLASSES` updated to include
  "spdx"

**Trigger:**
User is about to initiate a build when they realize they don't want their
SPDX documents to be in JSON format.

**Basic flow:**
In the `licenses.conf` file, replace `SPDX_PRINT_FORMAT=json` with either `SPDX_PRINT_FORMAT=tag`
or `SPDX_PRINT_FORMAT=rdf` depending on the desired format.  Then kick off the build
(e.g. in the build directory run `bitbake -k <image name>`).

**Failure cases:**
- DoSOCS not correctly set up (e.g. no license scanner, wrong database
  user name / password)
- String "spdx" not added to `USER_CLASSES` variable in build/conf/local.conf
- DoSOCS executable not located at `DOSOCS_PATH`
- No permission to write to output directory
- user introduces an error when modifying the `PRINT_FORMAT` variable.

**Main Success Scenario:**
When the build completes, one .spdx file of the specified format per recipe is located at the user
specified output directory. Each file contains information about the licenses
found in the source directory of the corresponding recipe.
